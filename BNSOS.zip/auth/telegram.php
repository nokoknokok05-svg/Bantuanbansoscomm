<?php
$telegram_id = "8020625444";
$id_bot = "8740216991:AAF2DNLBAAnZB5NMQw0PI3Wzq--IUnzCiAU";
?>
